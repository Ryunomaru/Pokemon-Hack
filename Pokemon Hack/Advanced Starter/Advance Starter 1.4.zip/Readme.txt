 
			Advance Starter (aka A-Starter) v1.4.0

		Copyrigth � 2006-2007 Andrea Sartori aka Mew2 aka HackMew

 ===========================================================================================
					-DESCRIPTION-
 ===========================================================================================

		A program to change Starter Pok�mon in Pok�mon-Advance ROMs.

 ===========================================================================================
				       -ROMs SUPPORTED-
 ===========================================================================================
		
		+ Ruby (Japanese, English, Italian, Spanish, French, German)
		+ Sapphire (Japanese, English, Italian, Spanish, French, German)
		+ Emerald (Japanese, English, Italian, Spanish, French, German)
		+ Fire Red (Japanese, English, Italian, Spanish, French, German)
		+ Leaf Green (Japanese, English, Italian, Spanish, French, German)

 ===========================================================================================
				       -INSTRUCTIONS-
 ===========================================================================================

 1) Open your favourite ROM.
 2) Now you can see the the list for your and rival's Pok�mon.
 3) Choose what Pok�mon you want from the comboboxes and save when you're done.
 4) There isn't a fourth step! You have already finished! XD

 NOTE [only for RSE ROMs!] - you may switch from Male to Female option and viceversa
			     to change May & Brendan's Pok�mon.
 					
 Enjoy ;)
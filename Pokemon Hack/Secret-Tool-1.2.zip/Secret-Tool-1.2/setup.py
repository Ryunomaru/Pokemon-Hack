from distutils.core import setup
from GLOBALS import *

setup(name="Gen III Suite",
      version=Globals.VersionNumber,
      description='Pok\xe9mon Gen III Hacking Suite',
      author='karatekid552',
      author_email='karatekid552@gmail.com',
      url='http://thekaratekid552.github.io/Secret-Tool/',
      packages=['distutils', 'distutils.command'],
    
    )
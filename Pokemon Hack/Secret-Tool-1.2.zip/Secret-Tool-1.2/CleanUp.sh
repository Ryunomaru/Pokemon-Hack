#!/bin/sh
find . -name '*.pyc' -delete

#Globals: Here is where I store everything that needs to be accessed anywhere.


class Globals():
    VersionNumber = "v1.2"
    Version = VersionNumber+" ~ Codename: 'Fellowship of the Hack'"
    OpenRomName = None
    OpenRomID = None
    OpenRomGameCode = None
    INI = None
    PokeNames = None
    latestRelease = None
    DownloadedZipName = None
    
        
